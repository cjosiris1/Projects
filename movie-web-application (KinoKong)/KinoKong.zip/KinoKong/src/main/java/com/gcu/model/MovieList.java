package com.gcu.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="movies")
public class MovieList 
{
	private List<MovieModel> movies = new ArrayList<MovieModel>();
	
	/**
	 * gets movies as an xml element
	 * @return movies
	 */
	@XmlElement(name="movie")
	public List<MovieModel> getOrders()
	{
		return this.movies;
	}
	
	/**
	 * sets movies
	 * @param movies
	 * @return movies
	 */
	public void setMovies(List<MovieModel> movies)
	{
		this.movies = movies;
	}
}
