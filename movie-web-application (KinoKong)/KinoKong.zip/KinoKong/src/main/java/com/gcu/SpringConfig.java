package com.gcu;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import com.gcu.business.MovieBusinessService;
import com.gcu.business.MovieBusinessServiceInterface;
import com.gcu.business.UserBusinessService;
import com.gcu.business.UserBusinessServiceInterface;

/*
 * Bean configuration file
 */
@Configuration
public class SpringConfig 
{
	/**
	 * gets user business service as bean
	 * @return UserBusinessService
	 */
	@Bean(name="UserBusinessService")
	@Primary
	public UserBusinessServiceInterface getUserBusinessService()
	{
		return new UserBusinessService();
	}
	
	/**
	 * gets movie business service as bean
	 * @return MovieBusinessService
	 */
	@Bean(name="MoviesBusinessService")
	@Scope("prototype")
	public MovieBusinessServiceInterface getMoviesBusinessService()
	{
		return new MovieBusinessService();
	}
}
