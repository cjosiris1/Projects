package com.gcu.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.gcu.data.entity.UserEntity;
import com.gcu.data.repository.UsersRepository;
import com.gcu.model.UserModel;

/**
 * UsersDataService
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Service
public class UsersDataService implements DataAccessInterface<UserEntity>, UsersDataAccessInterface {

	@Autowired 
	private UsersRepository usersRepository;
	
	@SuppressWarnings("unused")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	/**
	 * Constructor
	 * @param usersRepository
	 * @param dataSource
	 */
	public UsersDataService(UsersRepository usersRepository, DataSource dataSource) {
		this.usersRepository = usersRepository;
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	/**
	 * finds all users stored
	 * @return users
	 */
	@Override
	public List<UserEntity> findAll() {
		List<UserEntity> users = new ArrayList<UserEntity>();
		
		try 
		{
			//Get all the Entity Users.
			Iterable<UserEntity> usersIterable = usersRepository.findAll();
			
			//Convert to list and return the list.
			users = new ArrayList<UserEntity>();
			usersIterable.forEach(users::add);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return users;
	}

	/**
	 * finds users by their id
	 * @param id
	 * @return userResponse
	 */
	@Override
	public UserEntity findById(Long id) {
		UserEntity userResponse = new UserEntity();
		try 
		{
			//find user by id
			Optional<UserEntity> user = usersRepository.findById(id);
			
			//get the entity of user found
			userResponse = user.get();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return userResponse;
	}

	/**
	 * creates users and stores them
	 * @param user
	 * @return true or false
	 */
	@Override
	public boolean create(UserEntity user) {
		try 
		{
			this.usersRepository.save(user);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * updates user data
	 * @param user
	 * @return true or false
	 */
	@Override
	public boolean update(UserEntity user) {
		try 
		{
			this.usersRepository.save(user);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * deletes user data permanently
	 * @param user
	 * @return true or false
	 */
	@Override
	public boolean delete(UserEntity user) {
		try 
		{
			this.usersRepository.delete(user);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * method to authenticate user with custom query statements
	 * @deprecated
	 * @param user
	 * @return true or false
	 */
	public boolean authenticateUser(UserModel user) {
		//sql statement 
		String sql = String.format("SELECT * FROM db_users WHERE email = '%s' AND password = '%s'", user.getEmail(), user.getPassword());
		try 
		{
			//execute query
			jdbcTemplateObject.execute(sql);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * deletes users by their id
	 * @param id
	 * @return false
	 */
	@Override
	public boolean deleteById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	
	/**
	 * finds users by their email
	 * @param email
	 * @return user or null
	 */
	@Override
	public UserEntity findByEmail(String email) {
		try 
		{
			//find user by id
			UserEntity user = usersRepository.findByEmail(email);
			
			return user;
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}

}
