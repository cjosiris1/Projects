package com.gcu.data;

import com.gcu.data.entity.UserEntity;

/**
 * UsersDataAccessInterface
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public interface UsersDataAccessInterface {
	
	/**
	 * find user by email
	 * @param email
	 * @return UserEntity
	 */
	public UserEntity findByEmail(String email);
}
