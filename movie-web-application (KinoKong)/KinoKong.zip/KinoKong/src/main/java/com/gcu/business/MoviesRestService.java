package com.gcu.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gcu.model.MovieList;
import com.gcu.model.MovieModel;

@RestController
@RequestMapping("/service")
public class MoviesRestService 
{
	@Autowired
	MovieBusinessServiceInterface service;
	
	/**
	 * gets movies as json
	 * @return MovieBusinessServiceInterface
	 */
	@GetMapping(path="/getjson", produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<MovieModel> getMoviesAsJson()
	{
		return service.getMovies();
	}
	
	/**
	 * gets movie list as xml
	 * @return list
	 */
	@GetMapping(path="/getxml", produces= {MediaType.APPLICATION_XML_VALUE})
	public MovieList getMoviesAsXml()
	{
		MovieList list = new MovieList();
		list.setMovies(service.getMovies());
		return list;
	}
	
	/**
	 * gets movies by their id
	 * @param id
	 * @return responseEntity
	 */
	@GetMapping(path="/getmovie/{id}")
	public ResponseEntity<?> getMovie(@PathVariable("id") Long id)
	{
		try
		{
			MovieModel movie = service.getMovieById(id);
			if(movie == null)
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>(movie, HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
