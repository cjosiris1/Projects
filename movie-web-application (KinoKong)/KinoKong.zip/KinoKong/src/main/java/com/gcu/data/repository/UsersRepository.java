package com.gcu.data.repository;

import org.springframework.data.repository.CrudRepository;

import com.gcu.data.entity.UserEntity;

/**
 * Users Repository
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public interface UsersRepository extends CrudRepository<UserEntity, Long> {
	/**
	 * find user by email
	 * @param email
	 * @return UserEntity
	 */
	UserEntity findByEmail(String email);
}
