package com.gcu.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="users")
public class UserList 
{
	private List<UserModel> users = new ArrayList<UserModel>();
	
	/**
	 * gets users as an xml element
	 * @return users
	 */
	@XmlElement(name="user")
	public List<UserModel> getOrders()
	{
		return this.users;
	}
	
	/**
	 * sets users
	 * @param users
	 * @return users
	 */
	public void setUsers(List<UserModel> users)
	{
		this.users = users;
	}
}