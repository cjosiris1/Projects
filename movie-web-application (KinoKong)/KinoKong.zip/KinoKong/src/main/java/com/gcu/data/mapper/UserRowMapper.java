package com.gcu.data.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.gcu.data.entity.UserEntity;

/**
 * User Row Mapper
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public class UserRowMapper implements RowMapper<UserEntity> {

	/**
	 * maps users to row
	 * @param rs
	 * @param rowNum
	 * @return UserEntity
	 */
	@Override
	public UserEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new UserEntity(rs.getLong("ID"), 
								rs.getString("email"), 
								rs.getString("password"), 
								rs.getString("first_name"),
								rs.getString("last_name"),
								rs.getString("phone_number"),
								rs.getString("role"));
	}

}
