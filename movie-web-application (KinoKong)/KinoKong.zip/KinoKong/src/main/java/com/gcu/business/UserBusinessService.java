package com.gcu.business;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.gcu.data.UsersDataService;
import com.gcu.data.entity.MoviesEntity;
import com.gcu.data.entity.UserEntity;
import com.gcu.model.MovieModel;
import com.gcu.model.UserModel;

/**
 * UserBusinessService
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Service
public class UserBusinessService implements UserBusinessServiceInterface, UserDetailsService {

	// Inject class-scoped variable service.
	@Autowired
	private UsersDataService service;
	
	/**
	 * gets users by their id
	 * @param id
	 * @return UserModel
	 */
	@Override
	public UserModel getUserById(Long id)
	{
		//Get Entity Movie
		UserEntity userEntity = service.findById(id);
		
		// Return Movie Model with Entity values
		return new UserModel(userEntity.getId(), 
								userEntity.getEmail(),
								userEntity.getPassword(),
								userEntity.getFirstName(),
								userEntity.getLastName(),
								userEntity.getPhoneNumber(),
								"user");
	}
	
	/**
	 * gets all users stored
	 * @return usersDomain
	 */
	@Override
	public List<UserModel> getUsers() {
		// Get all the Entity Users
		List<UserEntity> usersEntity = service.findAll();
		
		List<UserModel> usersDomain = new ArrayList<UserModel>();
		
		for(UserEntity entity : usersEntity) 
		{
			usersDomain.add(new UserModel(entity.getId(),
											entity.getEmail(),
											entity.getPassword(),
											entity.getFirstName(),
											entity.getLastName(),
											entity.getPhoneNumber(),
											entity.getRole()));
		}
		return usersDomain;
	}
	
	/**
	 * finds users by their id
	 * @param id
	 * @return userModel
	 */
	@Override
	public UserModel findById(Long id) 
	{
		// Get Entity User by Id
		UserEntity user = service.findById(id);
		
		UserModel userModel = new UserModel(user.getId(), 
												user.getEmail(),
												user.getPassword(),
												user.getFirstName(),
												user.getLastName(),
												user.getPhoneNumber(),
												user.getRole());
		return userModel;
	}

	/**
	 * registers user
	 * @param user
	 * @return UsersDataService
	 * @param userEntity
	 */
	@Override
	public void registerUser(UserModel user) {
		// Create user entity
		// Set default role for all users to user
		UserEntity userEntity = new UserEntity(user.getId(), 
												user.getEmail(),
												user.getPassword(),
												user.getFirstName(),
												user.getLastName(),
												user.getPhoneNumber(),
												"user");
		
		//add user to database
		service.create(userEntity);
	}


	/**
	 * authenticates users
	 * @param user
	 * @return UsersDataService
	 */
	@Override
	public boolean authenticateUser(UserModel user) {
		return service.authenticateUser(user);
	}


	/**
	 * load users by their username/email
	 * @param email
	 * @return User or UsernameNotFoundException
	 */
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		UserEntity user = service.findByEmail(email);
		if(user != null) 
		{
			List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			authorities.add(new SimpleGrantedAuthority("USER"));
			return new User(user.getEmail(), user.getPassword(), authorities);
		}
		else
		{
			throw new UsernameNotFoundException("username not found");
		}
	}
	
	/**
	 * deletes users by their id
	 * @param id
	 * @return UsersDataService
	 * @param id
	 */
	@Override
	public boolean deleteUserById(Long id) 
	{
		return service.deleteById(id);
	}

}
