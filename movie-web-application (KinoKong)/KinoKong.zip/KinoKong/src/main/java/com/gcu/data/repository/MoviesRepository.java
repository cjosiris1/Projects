package com.gcu.data.repository;

import org.springframework.data.repository.CrudRepository;

import com.gcu.data.entity.MoviesEntity;

/**
 * Movies Repository
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public interface MoviesRepository extends CrudRepository<MoviesEntity, Long> { }
