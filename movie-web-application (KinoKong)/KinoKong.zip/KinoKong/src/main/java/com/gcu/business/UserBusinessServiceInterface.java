package com.gcu.business;

import java.util.List;

import com.gcu.model.MovieModel;
import com.gcu.model.UserModel;

/**
 * User Business Service Interface
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public interface UserBusinessServiceInterface {

	/**
	 * retrieves all users
	 * @return list of users of type UserModel
	 */
	public List<UserModel> getUsers();
	
	/**
	 * adds user of type UserModel
	 * @param user
	 */
	public void registerUser(UserModel user);
	
	/**
	 * user authentication
	 * @param user
	 * @return true or false
	 */
	public boolean authenticateUser(UserModel user);

	/**
	 * deletes user by id
	 * @param id
	 * @return true or false
	 */
	public boolean deleteUserById(Long id);

	/**
	 * finds user by id
	 * @param id
	 * @return true or false
	 */
	public UserModel findById(Long id);
	
	/**
	 * gets user by id
	 * @param id
	 * @return user result
	 */
	public UserModel getUserById(Long id);
}
