package com.gcu.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.business.MovieBusinessServiceInterface;
import com.gcu.business.UserBusinessServiceInterface;
import com.gcu.model.MovieModel;
import com.gcu.model.UserModel;

/**
 * Admin Controller
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Controller
@RequestMapping("/admin")
public class AdminManageController {
	
	//inject MovieBusinessServiceInterface bean
	@Autowired
	private MovieBusinessServiceInterface movieService;
	
	//inject UserBusinessServiceInterface bean
	@Autowired
	private UserBusinessServiceInterface userService;

	/**
	 * displays admin page
	 * @param model
	 * @return admin page
	 */
	@GetMapping("/")
	public String showAdminPage(Model model) 
	{
		return "admin";
	}
	
	/**
	 * displays admin manage movies page
	 * @param model
	 * @return admin manage movies page view
	 */
	@GetMapping("/adminManageMovies")
	public String showAdminMoviesPage(Model model) 
	{
		//get movies list from business service and set the attribute
		model.addAttribute("moviesList", movieService.getMovies());
		model.addAttribute("movieModel", new MovieModel());
		
		return "adminManageMovies";
	}
	
	/**
	 * displays add movie form
	 * @param model
	 * @return admin add movie page view
	 */
	@GetMapping("/adminManageMovies/adminAddMovie")
	public String showAddMovieForm(Model model) 
	{
		// needs to be movieModel or bean is lost
		model.addAttribute("movieModel", new MovieModel());
		return "adminAddMovie";
	}
	
	/**
	 * displays edit movie page
	 * @param movieId
	 * @param model
	 * @return edit movie form page view
	 */
	@GetMapping("/adminManageMovies/{movieId}/adminEditMovie")
	public String showEditMovieForm(@PathVariable long movieId, Model model) 
	{
		MovieModel movie = null;
		movie = movieService.findById(movieId);
		
		model.addAttribute("movie", movie);
		return "adminEditMovie";
	}
	
	/**
	 * Add movie
	 * @param movie
	 * @param bindingResult
	 * @param model
	 * @return admin manage movie page view
	 */
	@PostMapping("/adminManageMovies/adminAddMovie/processAddmovie")
	public String processAddMovie(@Valid MovieModel movie, BindingResult bindingResult, Model model)
	{
		// check for data validation errors
		if (bindingResult.hasErrors()) 
		{
			model.addAttribute("title", "Add Movie Form");
			// needs to be movie or bean is lost
			model.addAttribute("movie", new MovieModel());
			return "adminAddMovie";
		}
		
		//add movie to the list
		movieService.addMovie(movie);
		
		
		//get movies list from business service and set the attribute
		model.addAttribute("moviesList", movieService.getMovies());
		
		// return the view
		return "adminManageMovies";
	}
	
	/**
	 * Edit movie
	 * @param movieId
	 * @param movie
	 * @param model
	 * @return admin manage movies page view
	 */
	@PostMapping("/adminManageMovies/{movieId}/adminEditMovie/processEditMovie")
	public String processEditMovie(@PathVariable long movieId, @ModelAttribute("movie") MovieModel movie, Model model)
	{
		//set id and edit movie
		movie.setId(movieId);
		movieService.editMovie(movie);
		
		//get movies list from business service and set the attribute
		model.addAttribute("moviesList", movieService.getMovies());
		
		// return the view
		return "adminManageMovies";
	}
	
	/**
	 * displays movie by id
	 * @param model
	 * @param movieId
	 * @return movie page view
	 */
	@GetMapping("/adminManageMovies/{movieId}")
	public String showMovieById(Model model, @PathVariable long movieId) 
	{
		//get movie by id and set the model attribute
		MovieModel movie = null;
		movie = movieService.findById(movieId);
		model.addAttribute("movie", movie);
		
		//return view
		return "movie";
	}
	
	/**
	 * dispays delete movie by id form
	 * @param model
	 * @param movieId
	 * @return movie page view
	 */
	@GetMapping("/adminManageMovies/{movieId}/delete")
	public String showDeleteMovieById(Model model, @PathVariable long movieId) 
	{
		//get movie by id and set the model attributes
		MovieModel movie = null;
		movie = movieService.findById(movieId);
		model.addAttribute("allowDelete", true);
		model.addAttribute("movie", movie);
		
		//return view
		return "movie";
	}
	
	/**
	 * Delete movie
	 * @param movieId
	 * @param movie
	 * @param model
	 * @return admin manage movies page view
	 */
	@PostMapping("/adminManageMovies/{movieId}/delete")
	public String processDeleteMovieById(@PathVariable long movieId, @ModelAttribute("movie") MovieModel movie, Model model)
	{
		//delete movie by id
		movieService.deleteMovieById(movieId);
		
		model.addAttribute("moviesList", movieService.getMovies());
		
		// return the view
		return "adminManageMovies";
	}
	
	// ADMIN USERS
	//--------------------------------------------------------------------------------------------------------------------------------------------
	/**
	 * displays admin manage users page
	 * @param model
	 * @return admin manage users page view
	 */
	@GetMapping("/adminManageUsers")
	public String showAdminUsersPage(Model model) 
	{
		//get users list from business service and set the attribute
		model.addAttribute("usersList", userService.getUsers());
		model.addAttribute("userModel", new UserModel());
		
		return "adminManageUsers";
	}
	
	/**
	 * displays delete user by id form
	 * @param model
	 * @param userId
	 * @return user page view
	 */
	@GetMapping("/adminManageUsers/{userId}/delete")
	public String showDeleteUserById(Model model, @PathVariable long userId) 
	{
		//get user by id and set the model attributes
		UserModel user = null;
		user = userService.findById(userId);
		model.addAttribute("allowDelete", true);
		model.addAttribute("user", user);
		
		//return view
		return "user";
	}
	
	/**
	 * Delete user
	 * @param userId
	 * @param user
	 * @param model
	 * @return admin manage users page view
	 */
	@PostMapping("/adminManageUsers/{userId}/delete")
	public String processDeleteUserById(@PathVariable long userId, @ModelAttribute("user") UserModel user, Model model)
	{
		//delete user by id
		userService.deleteUserById(userId);
		
		model.addAttribute("usersList", userService.getUsers());
		
		// return the view
		return "adminManageUsers";
	}
}
