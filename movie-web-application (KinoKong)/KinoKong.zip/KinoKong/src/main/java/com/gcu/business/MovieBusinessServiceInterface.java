package com.gcu.business;

import java.util.List;

import com.gcu.model.MovieModel;

/**
 * Movie Bussiness Service Interface
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public interface MovieBusinessServiceInterface
{
	/**
	 * returns movie list.
	 * @return movies
	 */
	public List<MovieModel> getMovies();
	
	/**
	 * adds movie object to list
	 * @param movie
	 */
	public void addMovie(MovieModel movie);
	
	/**
	 * edit movie
	 * @param movie
	 * @return true or false
	 */
	public boolean editMovie(MovieModel movie);
	
	/**
	 * find movie by id
	 * @param id
	 * @return MovieModel
	 */
	public MovieModel findById(Long id);
	
	/**
	 * deletes movie by id
	 * @param id
	 * @return true or false
	 */
	public boolean deleteMovieById(Long id);
	
	/**
	 * gets movie by id
	 * @param id
	 * @return MovieModel
	 */
	public MovieModel getMovieById(Long id);
}