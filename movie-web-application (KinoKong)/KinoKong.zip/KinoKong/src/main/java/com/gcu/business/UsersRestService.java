package com.gcu.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gcu.model.MovieList;
import com.gcu.model.MovieModel;
import com.gcu.model.UserList;
import com.gcu.model.UserModel;

@RestController
@RequestMapping("/userService")
public class UsersRestService 
{
	@Autowired
	UserBusinessServiceInterface service;
	
	/**
	 * gets users as json
	 * @return users
	 */
	@GetMapping(path="/getjson", produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<UserModel> getUsersAsJson()
	{
		return service.getUsers();
	}
	
	/**
	 * gets users list as xml
	 * @return list
	 */
	@GetMapping(path="/getxml", produces= {MediaType.APPLICATION_XML_VALUE})
	public UserList getUsersAsXml()
	{
		UserList list = new UserList();
		list.setUsers(service.getUsers());
		return list;
	}
	
	/**
	 * gets users by their id
	 * @param id
	 * @return responseEntity
	 */
	@GetMapping(path="/getuser/{id}")
	public ResponseEntity<?> getUser(@PathVariable("id") Long id)
	{
		try
		{
			UserModel user = service.getUserById(id);
			if(user == null)
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>(user, HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}