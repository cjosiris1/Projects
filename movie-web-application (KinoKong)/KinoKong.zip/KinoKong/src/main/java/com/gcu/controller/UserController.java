package com.gcu.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.business.MovieBusinessServiceInterface;
import com.gcu.business.UserBusinessServiceInterface;
import com.gcu.model.UserModel;

/**
 * User Controller
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Controller
@RequestMapping("/user")
public class UserController 
{
	//inject the bean 
	@Autowired
	private UserBusinessServiceInterface userService;
	
	@Autowired
	private MovieBusinessServiceInterface moviesService;
	
	/**
	 * Display login form
	 * @param model
	 * @return view
	 */
	@GetMapping("/login")
	public String showLoginForm(Model model) 
	{
		
		// set model attributes and return view with the model
		model.addAttribute("title", "Sign In");
		model.addAttribute("userModel", new UserModel());
		return "login";
	}
	
	/**
	 * Displays registration form
	 * @param model
	 * @return view
	 */
	@GetMapping("/register")
	public String showRegistrationForm(Model model) 
	{
		// set model attributes and return view with the model
		model.addAttribute("title", "Registration Form");
		model.addAttribute("userModel", new UserModel());
		return "register";
	}

	/**
	 * Authenticate user
	 * @deprecated
	 * @param user
	 * @param bindingResult
	 * @param model
	 * @return view
	 */
	@PostMapping("/login/process_login")
	public String processAuthenticateUser(UserModel user, BindingResult bindingResult, Model model) 
	{	
		//set model attributes
		//users list is set to users
		model.addAttribute("users", userService.getUsers());
		
		
		//authenticate user if true return login success page, otherwise return login failed page.
		if(userService.authenticateUser(user) == true) 
		{
			//get the movie list from business service and set the model attribute 
			model.addAttribute("moviesList", moviesService.getMovies());
			
			return "movies";
		}
		else 
		{
			return "login_failed";
		}
	}
	
	/**
	 * Register User form
	 * @param user
	 * @param bindingResult
	 * @param model
	 * @return view
	 */
	@PostMapping("register/process_register")
	public String processRegisterUser(@Valid UserModel user, BindingResult bindingResult, Model model)
	{
		
		// check for validation errors
		if (bindingResult.hasErrors()) 
		{
			model.addAttribute("title", "Registration Form");
			model.addAttribute("user", user);
			return "register";
		}
		
		//register user and add to list of registered users.
		userService.registerUser(user);
		
		// return the user to main page
		return "index";
	}
	
}
