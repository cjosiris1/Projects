package com.gcu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.business.MovieBusinessServiceInterface;
import com.gcu.model.MovieModel;


/**
 * Main controller
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Controller
@RequestMapping("/")
public class MainController {
	
	@Autowired
	private MovieBusinessServiceInterface moviesService;
	
	
	/**
	 * Displays index page
	 * @return view
	 */
	@RequestMapping("/index")
	public String displayMain(Model model) 
	{
		//get the movie list from business service and set the model attribute 
		model.addAttribute("moviesList", moviesService.getMovies());
				
		return "index";
	}
	
	
	/**
	 * display movies catalog
	 * @param model
	 * @return view
	 */
	@GetMapping("/movies")
	public String displayMovies(Model model) 
	{
		//get the movie list from business service and set the model attribute 
		model.addAttribute("moviesList", moviesService.getMovies());
		
		//return the view
		return "movies";
	}
	
	@GetMapping("/movies/{movieId}")
	public String showMovieById(Model model, @PathVariable long movieId) 
	{
		//get movie by id and set the model attribute
		MovieModel movie = null;
		movie = moviesService.findById(movieId);
		model.addAttribute("movie", movie);
		
		//return view
		return "movieDetails";
	}
	
	/**
	 * display contact us page
	 * @return view
	 */
	@RequestMapping("/contactus")
	public String displayContactUs() 
	{
		//return the view
		return "contactus";
	}
	
	/**
	 * Displays about us page
	 * @return view
	 */
	@RequestMapping("/aboutus")
	public String displayAboutUs() 
	{
		//return the view
		return "aboutus";
	}
}
