package com.gcu.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

/**
 * Movie Model
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public class MovieModel
{
	// Movie's Assigned ID
	@Id
	private Long id;
	
	// Movie Name
	@NotNull(message="required field!")
	@Size(min=1, max=20, message="Movie Name must be at least 1 char long (max: 20 char long).")
	private String movieName;
	
	// Movie Cover Image
	@NotNull(message="required field!")
	@Size(min=1, max=20, message="Movie Image must be at least 1 char long (max: 20 char long).")
	private String movieImage;
	
	// Movie Trailer Link
	@NotNull(message="required field!")
	@Size(min=1, max=100, message="Movie Trailer Link must be at least 1 char long (max: 100 char long).")
	private String movieTrailer;
	
	// Movie's Release Date
	@NotNull(message="required field!")
	@Size(min=1, max=20, message="Release Date must be at least 1 char long (max: 20 char long).")
	private String releaseDate;
	
	// Movie's Actors
	@NotNull(message="required field!")
	@Size(min=1, max=50, message="Actors must be at least 1 char long (max: 50 char long).")
	private String actors;
	
	// Movie's Genre
	@NotNull(message="required field!")
	@Size(min=1, max=20, message="Movie Genre must be at least 1 char long (max: 20 char long).")
	private String movieGenre;
	
	// Movie's Country of Origin
	@NotNull(message="required field!")
	@Size(min=1, max=20, message="Country of Origin must be at least 1 char long (max: 20 char long).")
	private String countryOfOrigin;
	
	// User Rating
	private String userRating;
	
	/**
	 * Constructor
	 * @param id
	 * @param movieName
	 * @param movieImage
	 * @param movieTrailer
	 * @param releaseDate
	 * @param actors
	 * @param movieGenre
	 * @param countryOfOrigin
	 * @param userRating
	 */
	public MovieModel(Long id, String movieName, String movieImage, String movieTrailer, String releaseDate, String actors, String movieGenre, String countryOfOrigin, String userRating) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.movieImage = movieImage;
		this.movieTrailer = movieTrailer;
		this.releaseDate = releaseDate;
		this.actors = actors;
		this.movieGenre = movieGenre;
		this.countryOfOrigin = countryOfOrigin;
		this.userRating = userRating;
	}

	//empty constructor
	public MovieModel() {}

	/*
	 * getter and setter methods
	 */
	
	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getMovieImage() {
		return movieImage;
	}

	public void setMovieImage(String movieImage) {
		this.movieImage = movieImage;
	}

	public String getMovieTrailer() {
		return movieTrailer;
	}

	public void setMovieTrailer(String movieTrailer) {
		this.movieTrailer = movieTrailer;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getActors() {
		return actors;
	}

	public void setActors(String actors) {
		this.actors = actors;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public String getUserRating() {
		return userRating;
	}

	public void setUserRating(String userRating) {
		this.userRating = userRating;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
}