package com.gcu.data;

import java.util.List;

/**
 * DataAccessInterface
 * @author Daniyar Abeuov and Charles Osiris
 *
 * @param <T>
 */
public interface DataAccessInterface <T> {

	/**
	 * find all
	 * @return list<T>
	 */
	public List<T> findAll();
	
	/**
	 * find by id
	 * @param id
	 * @return T
	 */
	public T findById(Long id);
	
	/**
	 * add
	 * @param t
	 * @return true or false
	 */
	public boolean create(T t);
	
	/**
	 * edit
	 * @param t
	 * @return true or false
	 */
	public boolean update(T t);
	
	/**
	 * delete
	 * @param t
	 * @return true or false
	 */
	public boolean delete(T t);
	
	/**
	 * delete by id
	 * @param id
	 * @return true or false
	 */
	public boolean deleteById(Long id);
}
