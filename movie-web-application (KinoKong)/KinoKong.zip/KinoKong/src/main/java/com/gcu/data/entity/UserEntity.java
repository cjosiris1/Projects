package com.gcu.data.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

/**
 * User Entity
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Table("db_users")
public class UserEntity {
	@Id
	Long id;
	
	@Column("email")
	String email;
	
	@Column("password")
	String password;
	
	@Column("first_name")
	String firstName;
	
	@Column("last_name")
	String lastName;
	
	@Column("phone_number")
	String phoneNumber;
	
	@Column("role")
	String role;

	/**
	 * Constructor
	 * @param id
	 * @param email
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param phoneNumber
	 * @param role
	 */
	public UserEntity(Long id, String email, String password, String firstName, String lastName, String phoneNumber,
			String role) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.role = role;
	}
	
	public UserEntity() {}

	/**
	 * gets user id
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * sets user id
	 * @param id
	 * @return id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * gets user email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * sets user email
	 * @param email
	 * @return email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * gets user passwords
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * sets user passwords
	 * @param password
	 * @return password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * gets user's first name
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * sets user's first name
	 * @param firstName
	 * @return firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * gets user's last name
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * sets user's last name
	 * @param lastName
	 * @return lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/*
	 * gets user's phone number
	 * @return phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * sets user's phone number
	 * @param phoneNumber
	 * @return phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * gets user's role
	 * @return role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * sets user's role
	 * @param role
	 * @return role
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
}
