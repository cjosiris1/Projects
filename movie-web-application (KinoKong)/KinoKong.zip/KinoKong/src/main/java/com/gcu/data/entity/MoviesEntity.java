package com.gcu.data.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

/**
 * Movie Entity
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Table("db_movie")
public class MoviesEntity {

	@Id
	Long id;
	
	@Column("movie_name")
	String movieName;
	
	@Column("movie_image")
	String movieImage;
	
	@Column("movie_trailer")
	String movieTrailer;
	
	@Column("release_date")
	String releaseDate;
	
	@Column("actors")
	String movieActors;
	
	@Column("movie_genre")
	String movieGenre;
	
	@Column("country_of_origin")
	String countryOfOrigin;
	
	@Column("user_rating")
	String userRating;

	/**
	 * Constructor
	 * @param id
	 * @param movieName
	 * @param movieImage
	 * @param movieTrailer
	 * @param releaseDate
	 * @param movieActors
	 * @param movieGenre
	 * @param countryOfOrigin
	 * @param userRating
	 */
	public MoviesEntity(Long id, String movieName, String movieImage, String movieTrailer, String releaseDate,
			String movieActors, String movieGenre, String countryOfOrigin, String userRating) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.movieImage = movieImage;
		this.movieTrailer = movieTrailer;
		this.releaseDate = releaseDate;
		this.movieActors = movieActors;
		this.movieGenre = movieGenre;
		this.countryOfOrigin = countryOfOrigin;
		this.userRating = userRating;
	}
	
	/**
	 * getters and setters
	 */
	public MoviesEntity() {}

	/**
	 * get movie id
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * set movie id
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * 
	 * @return movie name
	 */
	public String getMovieName() {
		return movieName;
	}

	/**
	 * set movie name
	 * @param movieName
	 */
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	/**
	 * get movie image
	 * @return movie image
	 */
	public String getMovieImage() {
		return movieImage;
	}

	/**
	 * set movie image
	 * @param movieImage
	 */
	public void setMovieImage(String movieImage) {
		this.movieImage = movieImage;
	}

	/**
	 * get Movie trailer link
	 * @return Movie trailer link
	 */
	public String getMovieTrailer() {
		return movieTrailer;
	}

	/**
	 * set movie trailer link
	 * @param movieTrailer
	 */
	public void setMovieTrailer(String movieTrailer) {
		this.movieTrailer = movieTrailer;
	}

	/**
	 * get movie release date
	 * @return movie release date
	 */
	public String getReleaseDate() {
		return releaseDate;
	}

	/**
	 * set movie release date
	 * @param releaseDate
	 */
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	/**
	 * get movie actors
	 * @return movie actors
	 */
	public String getMovieActors() {
		return movieActors;
	}

	/**
	 * set movie actors
	 * @param movieActors
	 */
	public void setMovieActors(String movieActors) {
		this.movieActors = movieActors;
	}

	/**
	 * get movie genre
	 * @return movie genre
	 */
	public String getMovieGenre() {
		return movieGenre;
	}

	/**
	 * set movie genre
	 * @param movieGenre
	 */
	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	/**
	 * get movie country of origin
	 * @return movie country of origin
	 */
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
	
	/**
	 * set movie country of origin
	 * @param countryOfOrigin
	 */
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	/**
	 * get user ratings
	 * @return user rating
	 */
	public String getUserRating() {
		return userRating;
	}

	/**
	 * set user ratings
	 * @param userRating
	 */
	public void setUserRating(String userRating) {
		this.userRating = userRating;
	}
	
	
	
}
