package com.gcu.business;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.gcu.data.MoviesDataService;
import com.gcu.data.entity.MoviesEntity;
import com.gcu.model.MovieModel;

/**
 * MovieBusinessService
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public class MovieBusinessService implements MovieBusinessServiceInterface
{
	@Autowired
	private MoviesDataService service;
	
	/**
	 * gets movies their by id
	 * @param id
	 * @return MovieModel
	 */
	@Override
	public MovieModel getMovieById(Long id)
	{
		//Get Entity Movie
		MoviesEntity movieEntity = service.findById(id);
		
		// Return Movie Model with Entity values
		return new MovieModel(movieEntity.getId(), 
								movieEntity.getMovieName(),
								movieEntity.getMovieImage(),
								movieEntity.getMovieTrailer(),
								movieEntity.getReleaseDate(),
								movieEntity.getMovieActors(),
								movieEntity.getMovieGenre(),
								movieEntity.getCountryOfOrigin(),
								movieEntity.getUserRating());
	}
	
	/**
	 * gets movies as list
	 * @return moviesDomain
	 */
	@Override
	public List<MovieModel> getMovies() 
	{
		//Get all the Entity Movies
		List<MoviesEntity> moviesEntity = service.findAll();
		
		List<MovieModel> moviesDomain = new ArrayList<MovieModel>();
		
		for(MoviesEntity entity : moviesEntity) 
		{
			moviesDomain.add(new MovieModel(entity.getId(),
											entity.getMovieName(),
											entity.getMovieImage(),
											entity.getMovieTrailer(),
											entity.getReleaseDate(),
											entity.getMovieActors(),
											entity.getMovieGenre(),
											entity.getCountryOfOrigin(),
											entity.getUserRating()));
		}
		return moviesDomain;
	}

	/**
	 * adds movies to list
	 * @param movie
	 * @return MoviesDataService
	 * @param movieEntity
	 */
	@Override
	public void addMovie(MovieModel movie) 
	{
		//Create Movie Entity
		MoviesEntity movieEntity = new MoviesEntity(movie.getId(), 
													movie.getMovieName(),
													movie.getMovieImage(),
													movie.getMovieTrailer(),
													movie.getReleaseDate(),
													movie.getActors(),
													movie.getMovieGenre(),
													movie.getCountryOfOrigin(),
													movie.getUserRating());
		
		//Add Movie to Database
		service.create(movieEntity);
	}

	/**
	 * edit movies from list
	 * @param movie
	 * @return moviesDataService
	 * @param movieEntity
	 */
	@Override
	public boolean editMovie(MovieModel movie) 
	{
		//Create Movie Entity
		MoviesEntity movieEntity = new MoviesEntity(movie.getId(), 
													movie.getMovieName(),
													movie.getMovieImage(),
													movie.getMovieTrailer(),
													movie.getReleaseDate(),
													movie.getActors(),
													movie.getMovieGenre(),
													movie.getCountryOfOrigin(),
													movie.getUserRating());

		return service.update(movieEntity);
	}

	/**
	 * find movies by their id
	 * @param id
	 * @return movieModel
	 */
	@Override
	public MovieModel findById(Long id) 
	{
		// Get Entity Movie by Id
		MoviesEntity movie = service.findById(id);
		
		MovieModel movieModel = new MovieModel(movie.getId(),
												movie.getMovieName(),
												movie.getMovieImage(),
												movie.getMovieTrailer(),
												movie.getReleaseDate(),
												movie.getMovieActors(),
												movie.getMovieGenre(),
												movie.getCountryOfOrigin(),
												movie.getUserRating());
		return movieModel;
	}
	
	/**
	 * deletes movies by their id
	 * @param id
	 * @return MoviesDataService
	 * @param id
	 */
	@Override
	public boolean deleteMovieById(Long id) 
	{
		return service.deleteById(id);
	}

}