package com.gcu.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

/**
 * User model
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public class UserModel {
	/**
	 * variables and data constraints
	 */
	@Id
	private Long id;
	
	@NotNull(message="required field")
	@Size(min=1, max=20, message="Email must be at least 1 char long (max: 20 char long).")
	private String email;
	
	@NotNull(message="required field")
	@Size(min=1, max=20, message="Password must be at least 1 char long (max: 20 char long).")
	private String password;
	
	@NotNull(message="required field")
	@Size(min=1, max=20, message="First Name must be at least 1 char long (max: 20 char long).")
	private String firstName;
	
	@NotNull(message="required field")
	@Size(min=1, max=20, message="Last Name must be at least 1 char long (max: 20 char long).")
	private String lastName;
	
	@NotNull(message="required field")
	@Size(min=1, max=20, message="Phone Number must be at least 1 char long (max: 20 char long).")
	private String phoneNumber;
	
	private String role;
	
	/**
	 * Empty Constructor
	 */
	public UserModel() {}
	
	/**
	 * Constructor
	 * @param id
	 * @param email
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param phoneNumber
	 * @param role
	 */
	public UserModel(Long id, String email, String password, String firstName, String lastName, String phoneNumber, String role) {
		this.id = id;
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.role = role;
	}

	/**
	 * get user email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * set user email
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * get user's password
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * sets user's password
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * gets user's first name
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * sets user's first name
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * gets user's last name
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * set user's last name
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * get user's phone number
	 * @return phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * set user phone number
	 * @param phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * get user's role
	 * @return role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * set user's role
	 * @param role
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * get user's id
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * set user's id
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	
}
