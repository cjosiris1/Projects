package com.gcu.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.gcu.data.entity.MoviesEntity;
import com.gcu.data.repository.MoviesRepository;
/**
 * Movies Data Service is a service that contains method implementations for CRUD
 * and other query operations.
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
@Service
public class MoviesDataService implements DataAccessInterface<MoviesEntity>{

	@Autowired 
	private MoviesRepository moviesRepository;
	
	@SuppressWarnings("unused")
	private DataSource dataSource;
	@SuppressWarnings("unused")
	private JdbcTemplate jdbcTemplateObject;
	
	/**
	 * Constructor
	 * @param moviesRepository
	 * @param dataSource
	 */
	public MoviesDataService(MoviesRepository moviesRepository, DataSource dataSource) {
		this.moviesRepository = moviesRepository;
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}


	/**
	 * returns list of all movies
	 * @return movies
	 */
	@Override
	public List<MoviesEntity> findAll() {
		
		List<MoviesEntity> movies = new ArrayList<MoviesEntity>();
		
		try 
		{
			//Get all the Entity Users.
			Iterable<MoviesEntity> moviesIterable = moviesRepository.findAll();
			
			//Convert to list and return the list.
			movies = new ArrayList<MoviesEntity>();
			moviesIterable.forEach(movies::add);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return movies;
	}

	/**
	 * returns the movie with corresponding id
	 * @param id
	 * @return movieResponse
	 */
	@Override
	public MoviesEntity findById(Long id) {
		MoviesEntity movieResponse = new MoviesEntity();
		try 
		{
			//find user by id
			Optional<MoviesEntity> movie = moviesRepository.findById(id);
			
			//get the entity of user found
			movieResponse = movie.get();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return movieResponse;
	}


	/**
	 * adds/saves to database new entry
	 * @param movie
	 * @return true or false
	 */
	@Override
	public boolean create(MoviesEntity movie) {
		try 
		{
			this.moviesRepository.save(movie);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}


	/**
	 * updates/edits existing movie entry in the database
	 * @param movie
	 * @return true or false
	 */
	@Override
	public boolean update(MoviesEntity movie) {
		try 
		{
			this.moviesRepository.save(movie);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * deletes a movie from database
	 * @param movie
	 * @return true or false
	 */
	@Override
	public boolean delete(MoviesEntity movie) {
		try 
		{
			this.moviesRepository.delete(movie);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}


	/**
	 * deletes a movie by id
	 * @param id 
	 * @return true or false
	 */
	@Override
	public boolean deleteById(Long id) {
		try 
		{
			this.moviesRepository.deleteById(id);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
}
