package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/*
 * Milestone Project 
 * This is a group project and our own work. 
 * Contributors: Danny Abeuov, Charles Osiris
 * CST-339 
 */

@ComponentScan({"com.gcu"})
@SpringBootApplication
public class MilestoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilestoneApplication.class, args);
	}

}
