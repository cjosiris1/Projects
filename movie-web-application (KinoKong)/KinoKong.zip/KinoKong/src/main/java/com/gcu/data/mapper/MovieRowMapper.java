package com.gcu.data.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.gcu.data.entity.MoviesEntity;

/**
 * Movie Row Mapper
 * @author Daniyar Abeuov and Charles Osiris
 *
 */
public class MovieRowMapper implements RowMapper<MoviesEntity>{

	/**
	 * maps movies to row
	 * @param rs
	 * @param rowNum
	 * @return MoviesEntity
	 */
	@Override
	public MoviesEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new MoviesEntity(rs.getLong("ID"), 
								rs.getString("movie_name"),
								rs.getString("movie_image"),
								rs.getString("movie_trailer"),
								rs.getString("release_date"),
								rs.getString("actors"),
								rs.getString("movie_genre"),
								rs.getString("country_of_origin"),
								rs.getString("user_rating"));
	}

}
