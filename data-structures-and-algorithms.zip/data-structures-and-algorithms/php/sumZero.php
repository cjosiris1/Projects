<?php
/*
    Given an integer n, return any array containing n unique integers such that they add up to 0.

    Example 1:
    Input: n = 5
    Output: [-7,-1,1,3,4]
    Explanation: These arrays also are accepted [-5,-1,1,2,3] , [-3,-1,2,-2,4].

    Example 2:
    Input: n = 3
    Output: [-1,0,1]

    Example 3:
    Input: n = 1
    Output: [0]

    Constraints:
        * 1 <= n <= 1000
 */

/**
 * Class Solution
 */
class Solution
{

    /**
     * @param Integer $n
     * @return Integer[]
     */
    function sumZero($n)
    {
        $result = $n % 2 != 0 ? [0] : [];

        for ($i = 1; $i <= $n; $i++) {
            if (sizeof($result) != $n) {
                $result[] = $i;
                $result[] = -$i;
            }

        }

        return $result;
    }

    /**
     * @param $n
     * @return array
     */
    function sumZero2($n)
    {
        $result = [];
        for ($i = 1; $i < (int)$n; $i++) {
            array_push($result, $i);
        }
        array_push($result, -array_sum($result));
        return $result;
    }
}