﻿namespace Milestone4
{
    partial class frmGUI1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbarGridSize = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblGridSize = new System.Windows.Forms.Label();
            this.btnPassToGUI2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tbarGridSize)).BeginInit();
            this.SuspendLayout();
            // 
            // tbarGridSize
            // 
            this.tbarGridSize.Location = new System.Drawing.Point(43, 113);
            this.tbarGridSize.Maximum = 100;
            this.tbarGridSize.Name = "tbarGridSize";
            this.tbarGridSize.Size = new System.Drawing.Size(467, 45);
            this.tbarGridSize.TabIndex = 0;
            this.tbarGridSize.Scroll += new System.EventHandler(this.tbarGridSize_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Minesweeper Grid Size";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(382, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Change properties: Min to 8 and Max to 30";
            // 
            // lblGridSize
            // 
            this.lblGridSize.AutoSize = true;
            this.lblGridSize.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGridSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGridSize.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblGridSize.Location = new System.Drawing.Point(516, 104);
            this.lblGridSize.Name = "lblGridSize";
            this.lblGridSize.Size = new System.Drawing.Size(0, 31);
            this.lblGridSize.TabIndex = 3;
            // 
            // btnPassToGUI2
            // 
            this.btnPassToGUI2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPassToGUI2.Location = new System.Drawing.Point(171, 212);
            this.btnPassToGUI2.Name = "btnPassToGUI2";
            this.btnPassToGUI2.Size = new System.Drawing.Size(135, 27);
            this.btnPassToGUI2.TabIndex = 4;
            this.btnPassToGUI2.Text = "Pass To Form 2";
            this.btnPassToGUI2.UseVisualStyleBackColor = true;
            this.btnPassToGUI2.Click += new System.EventHandler(this.btnPassToGUI2_Click);
            // 
            // frmGUI1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPassToGUI2);
            this.Controls.Add(this.lblGridSize);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbarGridSize);
            this.Name = "frmGUI1";
            this.Text = "GUI One";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbarGridSize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar tbarGridSize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblGridSize;
        private System.Windows.Forms.Button btnPassToGUI2;
    }
}

