﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone4
{
    public partial class frmGUI1 : Form
    {
        public frmGUI1()
        {
            InitializeComponent();
        }
        // declare static variables
        static int gridSize = 10;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// trackbar to set grid size
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbarGridSize_Scroll(object sender, EventArgs e)
        {
            // Read in the trackbar position for grid size
            gridSize = tbarGridSize.Value;
            lblGridSize.Text = tbarGridSize.Value.ToString();

                
        }

        /// <summary>
        /// button to pass to GUI 2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPassToGUI2_Click(object sender, EventArgs e)
        {
            // pass number of grid cells to gui 2
            frmGUI2 newGame = new frmGUI2(gridSize);
            newGame.ShowDialog();

        }
    }
}
